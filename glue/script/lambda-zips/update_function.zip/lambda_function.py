import urllib.parse
import boto3
import json
from jira import JIRA
import os

print('Loading function')

def upload_to_s3(response_json_str,id):
    # Set up the S3 client
    s3 = boto3.client('s3')

    # Define the S3 bucket and key
    bucket_name = 'taasapi-saas-poc'
    key = f'keysight/{id}.json'

    # Upload the JSON response to S3
    s3.put_object(
        Body=response_json_str,
        Bucket=bucket_name,
        Key=key
    )

def jira_authenticate(EMAIL, TOKEN, HOST):
    global jira
    options = {
        'server': HOST
    }
    jira = JIRA(options, basic_auth=(EMAIL, TOKEN))

def jira_issue_update(issue_key,event_json_str):
    print(issue_key)
    issue = jira.issue(issue_key)
    # issue.update(fields={'customfield_10037': {'value': severity_value}})
    jira.add_comment(issue, event_json_str)

def trigger_notify(issue_key):
        
    client = boto3.client('sns')
    snsArn = 'arn:aws:sns:us-east-1:968504157731:TaasApiSnsNotify'
    message = f"""
                    Hi Client,
                    
                    Latest Test Execution have test results and also uploaded on to s3: {issue_key}.
                    
                    Thanks,
                    MSS Bot.
                    """
    subject = f"Updated Jira Issue: {issue_key}"

    response = client.publish(
        TopicArn = snsArn,
        Message = message ,
        Subject = subject
    )
    
def lambda_handler(event, context):
    EMAIL = "akhil.kanugolu@dish.com"
    TOKEN = "ATATT3xFfGF0HjMYrEjhx8InbuEb7IFSeeCuql3OnGxkPFAxGIXvRRkyf6jIZbqJghe3CtWGDERsxSbj006RJFh_187tGgiyQgg7ZBworOCBtPH78CQVmQT1GYsYpg0qwA2JxXv3Y7NqcLtCTkeLOz_jM_5AL1xGXD-BmMhtOeWdYW_BqnJ2WRQ=06125895"
    HOST = "https://dish-wireless-network.atlassian.net/"
    jira_authenticate(EMAIL, TOKEN, HOST)
    
    issue_key=event['jira_issue']
    # Convert event JSON object to string
    event_json=json.dumps(event['result_response'])
        # Parse the result_response JSON string
    result_response = json.loads(event_json)
    
    # Extract the id value
    id = result_response['id']
    upload_to_s3(event_json,id)
    jira_issue_update(issue_key,event_json)
    # print(event_json['id'])
    trigger_notify(issue_key)
    
    return "Completed: S3 Upload, Jira Update, Notify Email/Slack"
