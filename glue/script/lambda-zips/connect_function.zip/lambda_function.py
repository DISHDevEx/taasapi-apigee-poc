import boto3
import requests
import urllib3
import time
import hashlib
import base64
import json


def login(ip, port, username, password):
    api_endpoint = f'https://{ip}:{port}/api/login'
    credentials = {
        'username': username,
        'password': password
    }

    response = requests.post(api_endpoint, json=credentials, verify=False)
    return response

def logout(ip, port, session_id):
    logout_endpoint = f'https://{ip}:{port}/api/logout'
    headers = {
        'Cookie': f'PHPSESSID={session_id}'
    }
    
    response = requests.post(logout_endpoint, headers=headers, verify=False)
    return response

def post_trigger(base_url,session_id,test_id):
    headers = {
        'Cookie': f'PHPSESSID={session_id}'
    }
    trigger_url=f'{base_url}/tests/{test_id}/resume'
    trigger_response = requests.post(trigger_url, headers=headers, verify=False)
    print(trigger_response)
    return trigger_response.status_code

def get_test_details_by_id(base_url,session_id,test_id):
    headers = {
        'Accept': 'application/json',
        'Cookie': f'PHPSESSID={session_id}'
    }
    test_details_url=f'{base_url}/tests/{test_id}'
    test_details_response = requests.get(test_details_url, headers=headers, verify=False)
    return test_details_response

def get_test_results(base_url,session_id,params):
    headers = {
        'Accept': 'application/json',
        'Cookie': f'PHPSESSID={session_id}'
    }
    test_results_url=f'{base_url}/testsresults'
    test_results_response = requests.get(test_results_url, headers=headers, params=params, verify=False)
    return test_results_response
    
def post_trigger_get_data(base_url,session_id,test_id):
    if post_trigger(base_url,session_id,test_id) == 200:
        test_details_response=get_test_details_by_id(base_url, session_id, test_id)
        if test_details_response.status_code == 200:
            data=test_details_response.json()     
            print(data)
            start_date = data['startDate']
            end_date = data['endDate']
            if end_date.startswith('2123'):
                end_date = '2023' + end_date[4:]
                params = {
                        'timeInterval': 'Last15Min',
                        'startDate': start_date,
                        'endDate': end_date,
                        'testid': test_id,
                        'limit' : 1
                }
                time.sleep(15)
                test_results_response=get_test_results(base_url,session_id,params)
                if test_results_response.status_code==200:
                    return test_results_response.json()['records'][0]

def jira_s3_lambda(payload_json):
    # Create an AWS Lambda client
    lambda_client = boto3.client('lambda')

    # Convert the payload to JSON
    payload_json = json.dumps(payload_json)

    # Invoke the target Lambda function asynchronously with payload
    response = lambda_client.invoke(
        FunctionName='taas-update-jira-s3',
        InvocationType='Event',  # Asynchronous invocation
        Payload=payload_json
    )
    
    
def lambda_handler(event, context):
    
    urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

    # API endpoint and credentials
    private_ip = '172.24.51.139'
    ec2_port = 443
    username = 'user1'
    password = 'dish01'
    
    testid =event["testid"]
    jira_issue = event["jira_issue"]
    
    # Make POST request to login
    login_response = login(private_ip, ec2_port, username, password)
    
    # Handle the login response
    if login_response.status_code == 200:
        session_id = login_response.cookies.get('PHPSESSID')
        print('Login successful')
        base_url = f'https://{private_ip}:{ec2_port}/api'

        # Get test types
        if session_id:
            test_response=post_trigger_get_data(base_url,session_id,testid)
            
            logout_response=logout(private_ip, ec2_port, session_id)
            if logout_response.status_code == 200:
                print('Logout successful')
            else:
                print('Logout failed')
            
    
    else:
        print('Login failed')
    
    payload_json = {
        "jira_issue": jira_issue ,
        "result_response": test_response
    }
    
    jira_s3_lambda(payload_json)
    
    return payload_json