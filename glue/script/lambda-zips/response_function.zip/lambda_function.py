import boto3
import csv
import json
from jira import JIRA

# Initialize the JIRA client
EMAIL = "akhil.kanugolu@dish.com"
TOKEN = "ATATT3xFfGF0HjMYrEjhx8InbuEb7IFSeeCuql3OnGxkPFAxGIXvRRkyf6jIZbqJghe3CtWGDERsxSbj006RJFh_187tGgiyQgg7ZBworOCBtPH78CQVmQT1GYsYpg0qwA2JxXv3Y7NqcLtCTkeLOz_jM_5AL1xGXD-BmMhtOeWdYW_BqnJ2WRQ=06125895"
HOST = "https://dish-wireless-network.atlassian.net/"
jira = JIRA(server=HOST, basic_auth=(EMAIL, TOKEN))

# Create an AWS Lambda and S3 client
s3 = boto3.client('s3')
lambda_client = boto3.client('lambda')
# Specify the S3 bucket and file details
bucket_name = 'taasapi-saas-poc'
file_name = 'auth-dim/test_case_auth_dim.csv'

def jira_search_issues_by_summary(project_val, summary_val):
    jql_query = f'project = {project_val} AND summary~"{summary_val}" AND status not in (Closed, Done, Rejected) order by created DESC'
    jira_issues = jira.search_issues(jql_query)
    if jira_issues:
        return True, jira_issues[0].key
    else:
        return False, ""

def jira_issue_create(project_val, summary_val, description_val, issue_type_val, assignee_val, reporter_val, severity_val):
    issue_dict = {
        "project": {"key": project_val},
        "summary": summary_val,
        "description": description_val,
        "issuetype": {"name": issue_type_val},
        "customfield_10037": {"value": severity_val},
        "assignee": {"accountId": assignee_val},
        "reporter": {"id": reporter_val}
    }

    new_issue = jira.create_issue(fields=issue_dict)

    return new_issue.key

def check_auth_dim(client, label):

    try:
        # Read the file from S3
        response = s3.get_object(Bucket=bucket_name, Key=file_name)
        file_content = response['Body'].read().decode('utf-8')

        # Parse the CSV file
        reader = csv.DictReader(file_content.splitlines())

        # Iterate over the rows in the CSV file
        for row in reader:
            if row['client'] == client and row['label'] == label:
                return row['summary'], row['testid']

        # If no matching client and label found
        return None, None

    except Exception as e:
        print("Error: {}".format(str(e)))
        return None, None

def get_org_tests(client):
    try:
        # Read the file from S3
        response = s3.get_object(Bucket=bucket_name, Key=file_name)
        file_content = response['Body'].read().decode('utf-8')

        # Parse the CSV file
        reader = csv.DictReader(file_content.splitlines())

        # Initialize a list to store the matching records
        matches = []

        # Iterate over the rows in the CSV file
        for row in reader:
            if row['client'] == client:
                # Create a dictionary for each matching record
                match = {
                    'summary': row['summary'],
                    'label': row['label']
                }
                matches.append(match)

        # Return the JSON object containing the matches
        return matches

    except Exception as e:
        print("Error: {}".format(str(e)))
        return None

def invoke_trigger_lambda(payload_json):
    # Convert the payload to JSON
    payload_json = json.dumps(payload_json)

    # Invoke the target Lambda function asynchronously with payload
    response = lambda_client.invoke(
        FunctionName='taas-api-connect-ec2',
        InvocationType='Event',  # Asynchronous invocation
        Payload=payload_json
    )

def lambda_handler(event, context):
    print(event)
    
    project = 'MSS'  # Replace with your project key
    description = 'Issue description - Created from Lambda'
    issue_type = 'Story'  # Replace with the appropriate issue type
    assignee = '61ef15e05a0988006b23ad14'
    reporter = '61955256fe9f300068ec3c17'  # Replace with the username of the reporter
    severity = 'Sev 3 - Minor'
    
    
    # event = json.loads(event)

    http_method = event['httpMethod']
    path = event['path']
    # query_string_parameters = event['queryStringParameters']
    param_data = event['queryStringParameters']
    # param_data = json.loads(query_string_parameters)
    body = event['body']
    
    
    client = param_data['client']

    if path == "/trigger" and http_method == "POST":
        label = param_data["label"]

        # Specify the desired client and label
        # Retrieve summary and test ID
        summary, testid = check_auth_dim(client, label)
    
        is_exist, jira_existing_issue = jira_search_issues_by_summary(project, summary)
        jira_type = ""
    
        # Get the test ID and summary
        if testid is not None and summary is not None:
            if not is_exist:
                issue_key = jira_issue_create(project, summary, description, issue_type, assignee, reporter, severity)
                jira_type = "New Ticket"
            else:
                issue_key = jira_existing_issue
                jira_type = "Existing Ticket"
    
            payload_json = {
                'testid': testid,
                'jira_issue': issue_key
            }
    
            invoke_trigger_lambda(payload_json)
    
            # Generate the HTML response
            html_response = f"""
            <html>
            <head><title>Jira Ticket</title></head>
            <body>
            <h1>Jira Ticket: {issue_key}</h1>
            <p>Jira Ticket Type: {jira_type}</p>
            </body>
            </html>
            """

            return {
                'statusCode': 200,
                'headers': {
                    'Content-Type': 'text/html',
                },
                'body': html_response
            }
        else:
            # Generate the HTML response
            html_response = "<html><head><title>No Test Case Present</title></head><body><h1>No Test Case Present</h1></body></html>"

            return {
                'statusCode': 200,
                'headers': {
                    'Content-Type': 'text/html',
                },
                'body': html_response
            }

    elif path == "/orgtests" and http_method == "GET":
        label = None
        org_tests = get_org_tests(client)

        # Generate the HTML response
        html_response = "<html><head><title>Organization Tests</title></head><body>"
        for test in org_tests:
            html_response += f"<h2>Summary: {test['summary']}</h2><p>Label: {test['label']}</p>"
        html_response += "</body></html>"

        return {
            'statusCode': 200,
            'headers': {
                'Content-Type': 'text/html',
            },
            'body': html_response
        }